# 3b1bd3

3blue1brown-style **scrubbable D3 timeline animations for React**. One
`Timeline` holds every keyframe and caption; `sample(t)` is a pure function of
time; a `Player` renders your scene from the sampled state over a 1280×720 SVG
stage. Ships with a bookshelf of primitives (function plots, matrices,
contours, vectors, packets, architecture nodes/zones/connections), KaTeX
captions, deterministic PRNG, Web Speech narration, and a Storybook "Motion"
panel that lets you retime keyframes by dragging — and save the edits back to
source.

## Quickstart

```bash
npm i 3b1bd3 react react-dom d3 katex
```

```tsx
import { Timeline, Player, ease, colors } from '3b1bd3';
import { FunctionPlot, Axes } from '3b1bd3';
import { scaleLinear } from 'd3';
import '3b1bd3/player.css';
import 'katex/dist/katex.min.css'; // KaTeX css is not bundled — bring your own

const x = scaleLinear([-3, 3], [140, 1140]);
const y = scaleLinear([-1.5, 1.5], [600, 120]);

const tl = new Timeline();
const axes = tl.channel('axes', 0);
const reveal = tl.channel('curve', 0);
tl.tween(axes, 1, { at: 0.3, dur: 1.0, ease: ease.draw });
tl.caption({ at: 0.5, dur: 3, text: 'A sine wave, drawn on', tex: 'y = \\sin x' });
const end = tl.tween(reveal, 1, { at: 1.2, dur: 1.6, ease: ease.draw });
tl.hold(end, 1);

export const Sine = () => (
  <Player timeline={tl} autoplay>
    {(s) => (
      <>
        <Axes x={x} y={y} reveal={s.get(axes)} />
        <FunctionPlot x={x} y={y} f={Math.sin} reveal={s.get(reveal)} color={colors.ACCENT} />
      </>
    )}
  </Player>
);
```

Space toggles play, arrows step beat-by-beat (captions are the beats),
Shift+arrows nudge by a second, `L` loops, and the range input scrubs.

## The scrubbability invariant

**Nothing in this suite animates itself.** All time lives in one `Timeline`;
`sample(t)` is a pure function of `t`, so seeking, scrubbing, and replaying
are exact. This is deliberately *not* `d3.transition`, which is
fire-and-forget and cannot seek. The corollaries:

- Primitives are pure functions of the props handed to them (`reveal`, `u`,
  `flow`, `glow`…). Drive them from sampled channels.
- Randomness comes from `mulberry32(seed)` at **build** time, never at sample
  time (`prng`), so every scrub sees the same noise.
- Path draw-on lengths are computed analytically (no DOM measurement) in the
  React primitives; the imperative `draw.writeOn` helper caches
  `getTotalLength()` per element — call `resetWriteOn` if you change a
  path's `d` (see the `3b1bd3/draw` docs comment).
- The clock is a rAF delta accumulator — or, when you pass `audio` to the
  `Player`, the `<audio>` element itself, so baked narration and animation
  can never drift.

Timelines are also **editable**: every keyframe/caption has a stable id, and
`describe()` / `updateKeyframe()` / `updateCaption()` / `subscribe()` /
`exportOverrides()` / `applyOverrides()` / `exportNarration()` power the
Motion editor below.

## Entry points

| Import | What's inside |
| --- | --- |
| `3b1bd3` | Root barrel: everything in `core` + `primitives`. |
| `3b1bd3/core` | `Timeline`, `stagger`, `ease.*`, `Player`/`Transport`/`usePlayback`, `Stage`/`Camera`, `Captions`, `MathLabel` (KaTeX), `CanvasLayer`, `colors.*`, `mulberry32`/`gaussian`, the motion bus. |
| `3b1bd3/primitives` | `Axes`, `FunctionPlot`, `Vec`, `NumberLine`, `Brace`, `MatrixGrid`, `ContourField`, `ParticleCloud`, `Packet`, `NodeBadge`, `TimerArc` — and the architecture set: `Zone`, `ServiceNode`, `Connection`, `RequestFlow`. |
| `3b1bd3/draw` | Imperative D3 helpers for selection-based scenes: `grid`, `arrowMarker`, `glowFilter`, `mathLabel`, `caption`, `writeOn`/`resetWriteOn`, progress-space `stagger`, `lerp`, `gaussianPair`. Pure/deterministic in `t`. |
| `3b1bd3/narrator` | Framework-free Web Speech narration: `speechify(text)` (rewrites code-ish text — arrows, paths, camelCase — into speakable words), `speak`, `cancelSpeech`, `isSpeechSupported`. |
| `3b1bd3/acts` | Act-based compat layer (see below). |
| `3b1bd3/storybook` | The Motion editor addon (the only entry that imports `storybook/*`). |
| `3b1bd3/player.css`, `3b1bd3/editor.css` | Player transport / editor panel styles. |

## The acts adapter (for act-based hosts)

Some hosts think in a sequence of named acts (`{ name, duration, hold, ease,
say }` — durations in **milliseconds**) instead of channels. `3b1bd3/acts`
ships that engine as a compat layer:

```ts
import { createTimeline, phase, actsFromTimeline } from '3b1bd3/acts';

const tl = createTimeline([
  { name: 'grid', duration: 800, hold: 300 },
  { name: 'curve', duration: 1600, say: 'The loss surface appears.' },
]);
const s = tl.sample(1200);      // { index, name, t (eased 0..1), time, progress }
const g = phase(tl, s, 'grid'); // 0 before the act, eased t during, 1 after
```

`actsFromTimeline(coreTimeline)` bridges the two worlds: each caption beat of
a channel `Timeline` becomes one act (`cap-<id>`, caption text as `say`,
silence until the next beat as `hold`). Note the units — the core `Timeline`
runs in **seconds**, acts run in **milliseconds**; the adapter multiplies by
1000.

## The Motion editor (Storybook addon)

A Figma-style timeline panel: captions + one row per channel, tween spans as
draggable bars, instant keys as diamonds, a scrubbing playhead, edit-time
voice narration, and a **save to source** button that writes retimes into a
colocated `overrides.json`.

Three hookups in your `.storybook/`:

```ts
// main.ts — dev-server save endpoint (path-allowlisted, serve-only)
import { motionSaveEndpointPlugin } from '3b1bd3/storybook';
export default {
  framework: '@storybook/react-vite',
  stories: ['../src/**/*.stories.tsx'],
  addons: ['./motion-addon.ts'], // or managerEntries via a preset
  viteFinal: async (cfg) => {
    cfg.plugins = [...(cfg.plugins ?? []),
      motionSaveEndpointPlugin({ root: process.cwd(), allow: ['src/viz/'] })];
    return cfg;
  },
};
```

```ts
// a manager entry (e.g. .storybook/manager.ts) — registers the panel
import { registerMotionAddon } from '3b1bd3/storybook';
import '3b1bd3/editor.css';
registerMotionAddon(); // { saveEndpoint, addonId, title } to customize
```

```ts
// preview.ts — relays every story's Player to the panel
import { createElement } from 'react';
import { MotionBridge } from '3b1bd3/storybook';
export default {
  decorators: [(story) => createElement(MotionBridge, null, story())],
};
```

The save endpoint defaults to `DEFAULT_SAVE_ENDPOINT` (`/__motion/save`);
override it with `registerMotionAddon({ saveEndpoint })` or
`setMotionSaveEndpoint(url)`, and give `motionSaveEndpointPlugin` the matching
`endpoint`. The plugin refuses paths containing `..`, absolute paths,
anything outside its `allow` prefixes, and (by default) any file not named
`…overrides.json`.

### The overrides.json pattern

A scene exposes its timeline to the addon and applies saved edits at build
time — the file in git is the source of truth:

```tsx
import overrides from './overrides.json';
const tl = buildScene();               // deterministic authoring
tl.applyOverrides(overrides);          // replay saved retimes

<Player timeline={tl}
        motion={{ file: 'src/viz/my-scene/overrides.json', slug: 'my-scene' }}
        audio={published ? { url: narrationMp3, cues } : undefined}>
  {(s) => <Scene s={s} />}
</Player>
```

Drag bars in the panel → the story re-samples live → **save to source**
writes the diff (`exportOverrides()`) into `overrides.json`. The panel's
`narration ⬇` button exports the caption script (`exportNarration()`) for
your TTS bake; feed the resulting MP3 + per-line cues back as `audio` and the
narration becomes the clock.

## Palette

Self-contained tokens in `colors` (no theme system required):

| Token | Value | Role |
| --- | --- | --- |
| `BG` / `surface` | `#0a0e1a` | stage background |
| `PANEL` | `#0d1321` | node/chip fills, heat-ramp floor |
| `TEXT` / `ink.primary` | `#e6edf6` | primary text |
| `MUTED` / `ink.secondary` | `#8da2be` | secondary text, axes |
| `GRID` / `ink.grid` | `rgba(148,163,184,0.16)` | gridlines |
| `ACCENT` | `#38bdf8` | sky — the protagonist |
| `SECONDARY` | `#a78bfa` | violet |
| `POSITIVE` | `#34d399` | emerald — success/response |
| `WARM` | `#fbbf24` | amber — emphasis, `HEAT_MAX` |
| `NEGATIVE` | `#fb7185` | rose — errors/failures |
| `TEAL` | `#2dd4bf` | teal |

Plus `heat(u)` (a `PANEL→ACCENT` sequential ramp for heatmaps),
`categorical` (fixed assignment order — assign by entity, never cycle),
`ink` (text/line hierarchy) and `font` (ui/math/mono stacks) for the `draw`
helpers.

## SSR note

Browser APIs are guarded: `useReducedMotion` checks `typeof window`,
`3b1bd3/narrator` no-ops when `speechSynthesis` is absent, and rendering only
touches the DOM inside effects. The `Player`/editor modules import their CSS
(`sideEffects: ["*.css"]` is declared), which bundlers handle transparently —
in a no-bundler Node environment, import the pure entries (`3b1bd3/acts`,
`3b1bd3/narrator`, `3b1bd3/draw`) or shim `.css` imports. KaTeX css is never
bundled; import `katex/dist/katex.min.css` yourself.

## License

MIT © Brett Lamy
